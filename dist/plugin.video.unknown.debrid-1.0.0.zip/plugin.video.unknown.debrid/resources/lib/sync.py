import json
import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import debrid, names

PLAY_URL = "plugin://{}/play/{}/{}"


def data_dir():
    path = xbmcvfs.translatePath("special://profile/addon_data/{}/".format(debrid.ADDON_ID))
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def library_dir():
    path = os.path.join(data_dir(), "library")
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def manifest_path():
    return os.path.join(data_dir(), "manifest.json")


def load_manifest():
    try:
        with open(manifest_path(), "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return {}


def save_manifest(manifest):
    with open(manifest_path(), "w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=1)


def target_path(parsed):
    root = library_dir()
    if parsed["kind"] == "episode":
        show = names.safe_name(parsed["show"])
        return os.path.join(root, "TV Shows", show, "Season {:02d}".format(parsed["season"]),
                            "{} S{:02d}E{:02d}.strm".format(show, parsed["season"], parsed["episode"]))
    title = names.safe_name(parsed["title"])
    folder = "{} ({})".format(title, parsed["year"]) if parsed.get("year") else title
    return os.path.join(root, "Movies", folder, folder + ".strm")


def build_entries(token, torrent):
    entries = []
    info = debrid.torrent_info(token, torrent["id"])
    for media in info.get("files", []):
        if not media.get("selected") or not names.is_video(media["path"]) or names.is_sample(media["path"]):
            continue
        parsed = names.parse(media["path"], torrent.get("filename", ""))
        if parsed["kind"] == "episode":
            key = "episode|{}|{}|{}".format(parsed["show"].lower(), parsed["season"], parsed["episode"])
        else:
            key = "movie|{}|{}".format(parsed["title"].lower(), parsed.get("year"))
        entries.append({
            "key": key,
            "kind": parsed["kind"],
            "title": parsed.get("title", ""),
            "year": parsed.get("year"),
            "show": parsed.get("show", ""),
            "season": parsed.get("season"),
            "episode": parsed.get("episode"),
            "name": os.path.basename(media["path"]),
            "file_id": str(media["id"]),
            "torrent": torrent["id"],
            "torrent_name": torrent.get("filename", ""),
            "path": target_path(parsed),
            "play": PLAY_URL.format(debrid.ADDON_ID, torrent["id"], media["id"]),
        })
    return entries


def collect(token, progress=None):
    manifest = load_manifest()
    desired = {}
    taken = set()
    remote = [t for t in debrid.torrents(token) if t.get("status") == "downloaded"]
    live_ids = set()
    total = len(remote)
    for position, torrent in enumerate(remote):
        torrent_id = torrent.get("id", "")
        live_ids.add(torrent_id)
        if progress:
            progress(int(position * 100 / max(total, 1)), torrent.get("filename", ""))
        cached = manifest.get(torrent_id)
        if cached and cached.get("filename") == torrent.get("filename"):
            entries = cached.get("files", [])
        else:
            entries = build_entries(token, torrent)
            manifest[torrent_id] = {"filename": torrent.get("filename", ""), "files": entries}
        for entry in entries:
            if entry["key"] in taken:
                debrid.log("Skipping duplicate: {} from {}".format(entry["key"], entry["torrent_name"]), xbmc.LOGINFO)
                continue
            taken.add(entry["key"])
            desired[entry["play"]] = entry
    return {tid: manifest[tid] for tid in live_ids if tid in manifest}, desired


def write_strm(path, url):
    directory = os.path.dirname(path)
    if not xbmcvfs.exists(directory):
        xbmcvfs.mkdirs(directory)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(url)


def remove_empty_dirs(root):
    for current, dirs, files in os.walk(root, topdown=False):
        if current != root and not dirs and not files:
            try:
                os.rmdir(current)
            except OSError:
                pass


def show_setup_hint(settings):
    if settings.getSettingBool("setup_shown"):
        return
    root = library_dir()
    movies = os.path.join(root, "Movies")
    shows = os.path.join(root, "TV Shows")
    if not xbmcvfs.exists(movies) and not xbmcvfs.exists(shows):
        return
    settings.setSettingBool("setup_shown", "true")
    xbmcgui.Dialog().ok(
        "Unknown Debrid",
        "One last step. In Kodi open Videos, then Files, then Add videos, and add these as sources:[CR][CR]"
        "{}[CR](set content: Movies)[CR][CR]{}[CR](set content: TV shows)[CR][CR]"
        "Kodi fills in posters and details, and your Real-Debrid titles appear on the home screen.".format(movies, shows))


def run_sync(notify=False, interactive=False):
    window = xbmcgui.Window(10000)
    if window.getProperty("UnknownDebrid.Syncing"):
        return
    window.setProperty("UnknownDebrid.Syncing", "true")
    dialog = None
    progress = None
    if interactive:
        dialog = xbmcgui.DialogProgress()
        dialog.create("Unknown Debrid", "Listing Real-Debrid torrents...")
        progress = lambda percent, name: dialog.update(percent, "Reading: {}".format(name))
    try:
        token = debrid.ensure_token()
        old = load_manifest()
        manifest, desired = collect(token, progress)
        old_paths = {entry["path"] for torrent in old.values() for entry in torrent.get("files", [])}
        new_paths = {entry["path"] for entry in desired.values()}
        removed = sorted(old_paths - new_paths)
        for path in removed:
            try:
                os.remove(path)
            except OSError:
                pass
        written = 0
        for entry in desired.values():
            if not os.path.exists(entry["path"]):
                write_strm(entry["path"], entry["play"])
                written += 1
        remove_empty_dirs(library_dir())
        save_manifest(manifest)
        settings = xbmcaddon.Addon()
        if (written or removed) and settings.getSettingBool("auto_scan"):
            if removed and settings.getSettingBool("auto_clean"):
                xbmc.executebuiltin("CleanLibrary(video)")
            xbmc.executebuiltin("UpdateLibrary(video)")
        debrid.log("Sync complete: {} written, {} removed, {} tracked".format(written, len(removed), len(desired)),
                   xbmc.LOGINFO)
        if dialog:
            dialog.close()
        if interactive:
            xbmcgui.Dialog().notification(
                "Unknown Debrid", "Library synced: {} new, {} removed".format(written, len(removed)),
                xbmcgui.NOTIFICATION_INFO, 4000)
            show_setup_hint(settings)
    except debrid.AuthExpired:
        if dialog:
            dialog.close()
        debrid.log("Sync skipped: no Real-Debrid account linked", xbmc.LOGINFO)
    except debrid.DebridError as error:
        if dialog:
            dialog.close()
        debrid.log("Sync failed: {}".format(error), xbmc.LOGWARNING)
        if notify or interactive:
            xbmcgui.Dialog().notification("Unknown Debrid", "Sync failed: {}".format(error),
                                          xbmcgui.NOTIFICATION_ERROR, 6000)
    finally:
        window.clearProperty("UnknownDebrid.Syncing")


def wipe():
    root = library_dir()
    for current, dirs, files in os.walk(root, topdown=False):
        for name in files:
            try:
                os.remove(os.path.join(current, name))
            except OSError:
                pass
        for name in dirs:
            try:
                os.rmdir(os.path.join(current, name))
            except OSError:
                pass
    save_manifest({})
    xbmc.executebuiltin("CleanLibrary(video)")


def run_service():
    monitor = xbmc.Monitor()
    try:
        debrid.ensure_token()
        linked = True
    except debrid.DebridError:
        linked = False
    if linked and xbmcaddon.Addon().getSettingBool("sync_on_startup"):
        run_sync()
    elif not linked:
        xbmcgui.Dialog().notification("Unknown Debrid",
                                      "Open Unknown Debrid to link your Real-Debrid account",
                                      xbmcgui.NOTIFICATION_INFO, 8000)
    last_sync = time.monotonic()
    while not monitor.waitForAbort(30):
        interval = xbmcaddon.Addon().getSettingInt("sync_interval") * 60
        if interval <= 0:
            last_sync = time.monotonic()
            continue
        if time.monotonic() - last_sync >= interval:
            run_sync()
            last_sync = time.monotonic()
